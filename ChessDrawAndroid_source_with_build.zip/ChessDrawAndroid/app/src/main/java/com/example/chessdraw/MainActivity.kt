package com.example.chessdraw

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 48, 36, 36)
        }
        layout.addView(TextView(this).apply {
            text = "CHESS DRAW\n\nБасқа қосымшалардың үстінен стрелка салу прототипі.\n\nЕскерту: осы алғашқы нұсқада сурет салу қабаты экрандағы түртулерді ұстап қалады, сондықтан Lichess/Chess.com жүрістерін тікелей жасауға кедергі келтіруі мүмкін."
            textSize = 18f
        })
        layout.addView(Button(this).apply {
            text = "1. Экран үстіне шығуға рұқсат беру"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                }
            }
        })
        layout.addView(Button(this).apply {
            text = "2. Стрелка сызуды бастау"
            setOnClickListener {
                if (Settings.canDrawOverlays(this@MainActivity)) {
                    startService(Intent(this@MainActivity, OverlayService::class.java))
                    finish()
                }
            }
        })
        layout.addView(Button(this).apply {
            text = "Қабатты тоқтату"
            setOnClickListener { stopService(Intent(this@MainActivity, OverlayService::class.java)) }
        })
        setContentView(layout)
    }
}
