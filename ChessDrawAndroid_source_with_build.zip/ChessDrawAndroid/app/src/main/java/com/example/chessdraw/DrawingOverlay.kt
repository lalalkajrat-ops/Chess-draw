package com.example.chessdraw

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin

class DrawingOverlay(context: Context) : View(context) {
    private data class Arrow(val x1: Float, val y1: Float, val x2: Float, val y2: Float)
    private val arrows = mutableListOf<Arrow>()
    private var active: Arrow? = null
    private var anchorPointer = -1
    private var drawPointer = -1
    private var lastTapTime = 0L
    private val slop = ViewConfiguration.get(context).scaledTouchSlop.toFloat()
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF20C878.toInt()
        strokeWidth = 12f
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val headPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF20C878.toInt()
        style = Paint.Style.FILL
    }

    init { setLayerType(View.LAYER_TYPE_HARDWARE, null) }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                anchorPointer = e.getPointerId(0)
                val now = System.currentTimeMillis()
                if (now - lastTapTime < 350) {
                    arrows.clear()
                    active = null
                    invalidate()
                    lastTapTime = 0L
                } else lastTapTime = now
                return true
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                if (drawPointer == -1 && e.pointerCount >= 2) {
                    val idx = e.actionIndex
                    drawPointer = e.getPointerId(idx)
                    val anchorIdx = e.findPointerIndex(anchorPointer)
                    if (anchorIdx >= 0) {
                        // The first finger is the hold point; the second finger defines the arrow.
                        active = Arrow(e.getX(anchorIdx), e.getY(anchorIdx), e.getX(idx), e.getY(idx))
                    }
                }
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val id = drawPointer
                if (id != -1) {
                    val idx = e.findPointerIndex(id)
                    val a = active
                    if (idx >= 0 && a != null) active = a.copy(x2 = e.getX(idx), y2 = e.getY(idx))
                    invalidate()
                }
                return true
            }
            MotionEvent.ACTION_POINTER_UP -> {
                val lifted = e.getPointerId(e.actionIndex)
                if (lifted == drawPointer) {
                    active?.let { arrows.add(it) }
                    active = null
                    drawPointer = -1
                    invalidate()
                }
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                active?.let { arrows.add(it) }
                active = null
                drawPointer = -1
                anchorPointer = -1
                invalidate()
                return true
            }
        }
        return true
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        arrows.forEach { drawArrow(canvas, it) }
        active?.let { drawArrow(canvas, it) }
    }

    private fun drawArrow(c: Canvas, a: Arrow) {
        c.drawLine(a.x1, a.y1, a.x2, a.y2, linePaint)
        val angle = atan2(a.y2 - a.y1, a.x2 - a.x1)
        val length = 34f
        val spread = 0.55
        val p = Path().apply {
            moveTo(a.x2, a.y2)
            lineTo(a.x2 - length * cos(angle - spread).toFloat(),
                a.y2 - length * sin(angle - spread).toFloat())
            lineTo(a.x2 - length * cos(angle + spread).toFloat(),
                a.y2 - length * sin(angle + spread).toFloat())
            close()
        }
        c.drawPath(p, headPaint)
    }
}
